<?php
namespace GQL;

trait ProductImageTypeResolver {
    
    public function ProductImageType_product ($root, $args, &$ctx) { return null; }

}
?>