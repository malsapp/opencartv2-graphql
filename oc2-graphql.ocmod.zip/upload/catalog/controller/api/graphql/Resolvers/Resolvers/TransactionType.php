<?php
namespace GQL;

trait TransactionTypeResolver {
    
    public function TransactionType_customer ($root, $args, &$ctx) { return null; }

}
?>