<?php
namespace GQL;

trait PhotoTypeResolver {
    
    public function PhotoType_description ($root, $args, $ctx) { return null; }

}
?>