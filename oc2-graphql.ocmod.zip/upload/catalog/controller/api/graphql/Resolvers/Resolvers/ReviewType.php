<?php
namespace GQL;

trait ReviewTypeResolver {
    
    public function ReviewType_product ($root, $args, &$ctx) { return null; }

}
?>