<?php
namespace GQL;

trait CouponTypeResolver {
    
    public function CouponType_categories ($root, $args, &$ctx) { return null; }

    public function CouponType_products ($root, $args, &$ctx) { return null; }

    public function CouponType_status ($root, $args, &$ctx) { return null; }

    public function CouponType_type ($root, $args, &$ctx) { return null; }

}
?>