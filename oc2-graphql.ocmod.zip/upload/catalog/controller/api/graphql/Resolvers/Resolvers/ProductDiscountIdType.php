<?php
namespace GQL;

trait ProductDiscountIdTypeResolver {
    
    public function ProductDiscountIdType_Product ($root, $args, &$ctx) { return null; }

    public function ProductDiscountIdType_CustomerGroup ($root, $args, &$ctx) { return null; }

}
?>